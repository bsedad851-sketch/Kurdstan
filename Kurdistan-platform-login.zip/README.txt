KURDISTAN SPORTS PLATFORM — تسجيل الدخول الحقيقي

الملفات:
- index.html : واجهة المنصة وتسجيل الدخول.
- app.js     : ربط المصادقة مع Supabase.

مهم: لن تعمل الحسابات الحقيقية حتى تضبط Supabase. لا ترفع أي مفاتيح سرية.

خطوات التفعيل:
1) أنشئ مشروعاً في https://supabase.com
2) افتح Authentication > Providers > Email وتأكد أن Email مفعّل.
3) افتح Project Settings > API.
4) انسخ Project URL والصقه مكان PASTE_YOUR_SUPABASE_PROJECT_URL في app.js.
5) انسخ anon/public key والصقه مكان PASTE_YOUR_SUPABASE_ANON_KEY في app.js.
   استخدم anon/public فقط. لا تستخدم service_role key.
6) افتح Authentication > URL Configuration وأضف رابط GitHub Pages إلى Site URL و Redirect URLs:
   https://bsedad851-sketch.github.io/Kurdstan/
7) ارفع index.html و app.js إلى جذر مستودع GitHub نفسه (نفس مستوى الملفات)، ثم Commit changes.
8) انتظر انتهاء GitHub Actions وافتح رابط الموقع.

المنصة الآن تحتوي على واجهة تسجيل/إنشاء حساب، وبعد ضبط Supabase تصبح المصادقة حقيقية.
لوحة إدارة الأخبار والمباريات ليست مفعّلة في هذه النسخة بعد.
