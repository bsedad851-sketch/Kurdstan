// 1) أنشئ مشروعاً في https://supabase.com
// 2) من Project Settings > API انسخ Project URL و anon/public key
// 3) ألصقهما هنا. لا تستخدم service_role key في المتصفح.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";

const ready = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_ANON_KEY.startsWith("PASTE_") &&
  typeof window.supabase !== "undefined";
const client = ready ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const authPanel = document.getElementById("authPanel");
const appPanel = document.getElementById("appPanel");
const authForm = document.getElementById("authForm");
const msg = document.getElementById("authMessage");
const nameField = document.getElementById("nameField");
const nameInput = document.getElementById("displayName");
const password = document.getElementById("password");
const email = document.getElementById("email");
const submitBtn = document.getElementById("submitBtn");
const loginTab = document.getElementById("loginTab");
const signupTab = document.getElementById("signupTab");
const navUser = document.getElementById("navUser");
let mode = "login";

function message(text, good=false) {
  msg.textContent = text;
  msg.className = good ? "ok" : "muted";
}
function setMode(next) {
  mode = next;
  const signup = mode === "signup";
  nameField.classList.toggle("hidden", !signup);
  nameInput.required = signup;
  password.autocomplete = signup ? "new-password" : "current-password";
  submitBtn.textContent = signup ? "إنشاء حساب" : "تسجيل الدخول";
  loginTab.className = signup ? "secondary" : "";
  signupTab.className = signup ? "" : "secondary";
  message("");
}
loginTab.addEventListener("click", () => setMode("login"));
signupTab.addEventListener("click", () => setMode("signup"));

function showApp(user) {
  authPanel.classList.add("hidden");
  appPanel.classList.remove("hidden");
  const label = user.user_metadata?.display_name || user.email || "مستخدم";
  document.getElementById("profileLine").textContent = "الحساب: " + label;
  navUser.textContent = label;
}
function showAuth() {
  appPanel.classList.add("hidden");
  authPanel.classList.remove("hidden");
  navUser.textContent = "منصة الرياضة في كردستان";
}
if (!ready) {
  message("نظام الحسابات غير مفعّل بعد. اتبع خطوات إعداد Supabase في ملف README.txt.", false);
  submitBtn.disabled = true;
} else {
  client.auth.getSession().then(({data}) => {
    if (data.session) showApp(data.session.user);
  });
  client.auth.onAuthStateChange((_event, session) => {
    if (session) showApp(session.user);
    else showAuth();
  });
  authForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    submitBtn.disabled = true;
    message("جارٍ المعالجة...");
    try {
      if (mode === "signup") {
        const {data, error} = await client.auth.signUp({
          email: email.value.trim(),
          password: password.value,
          options: {data: {display_name: nameInput.value.trim()}}
        });
        if (error) throw error;
        if (data.session) showApp(data.session.user);
        else message("تم إنشاء الطلب. افحص بريدك الإلكتروني لتأكيد الحساب.", true);
      } else {
        const {data, error} = await client.auth.signInWithPassword({
          email: email.value.trim(), password: password.value
        });
        if (error) throw error;
        showApp(data.user);
      }
    } catch (error) {
      message(error.message || "حدث خطأ، حاول مرة أخرى.");
    } finally { submitBtn.disabled = false; }
  });
  document.getElementById("logoutBtn").addEventListener("click", async () => {
    const {error} = await client.auth.signOut();
    if (error) message(error.message);
    showAuth();
  });
}
